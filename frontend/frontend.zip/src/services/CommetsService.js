import axios from 'axios';
import environment from '../environment';

const CommentService = {

};
export default CommentService;