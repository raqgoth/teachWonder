import axios from 'axios';
import environment from '../environment';

const PostService = {

};

export default PostService;