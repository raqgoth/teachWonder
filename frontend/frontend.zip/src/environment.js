const BASE_URL   = 'http://127.0.0.1:4000';
const environment = {
   app:''
};

export default enviroment;